// This file is deprecated. Please use the geminiService.ts in the root directory.
export * from '../geminiService';